from queue import Queue

queue = Queue()