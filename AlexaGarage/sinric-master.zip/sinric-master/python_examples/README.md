# Python Examples

## Python-2.7 not supported
[![Downloads](https://pepy.tech/badge/pysinric)](https://pepy.tech/project/pysinric) [![Downloads](https://pepy.tech/badge/pysinric/week)](https://pepy.tech/project/pysinric/week) [![](https://img.shields.io/pypi/v/pysinric.svg)]() [![](https://img.shields.io/pypi/format/pysinric.svg)]() [![](https://img.shields.io/badge/author-Dhanush-brightgreen.svg)](https://github.com/imdhanush)
### Install sinric python package
    pip3 install pysinric --user

### Pysinric
   [pysinric](https://pypi.org/project/pysinric/)
   
### Upgrade Pysinric to lastest version
    python3 -m pip install pysinric --upgrade --user